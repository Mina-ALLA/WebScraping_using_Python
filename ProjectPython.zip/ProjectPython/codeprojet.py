﻿
import math 
import csv
csv.field_size_limit(1000000000)
path = "speechKingM6.csv"
file = open(path, newline='')
reader=csv.reader(file)
data = [row for row in reader]
#la liste data contient des lignes vides ainsi que des lignes qui se repetent donc il faut améliorer la liste data
#pour faire cela on suit les instructions suivantes jusqu'à la ligne 19
mydata=[]
for i in range(1, len(data)):
    if data[i]!=[]:
        mydata.insert(len(mydata),data[i])
        
data=[]
for i in range(0, len(mydata)-1):
    if mydata[i][1]!=mydata[i+1][1]:
        data.insert(len(data),mydata[i])
        
 # defining punctuations so we can elemenate them    
punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
a='\n'
for i in range(0, len(data)):
    #convert all characters to lowercase
        data[i][1]=data[i][1].lower()
    #remove all punctuation characters
        listecaracter=list(data[i][1])
        for j in range(0,len(listecaracter)):
            if listecaracter[j]  in punctuations :
                listecaracter[j]=" "
            if  listecaracter[j]==a :
                listecaracter[j]=" "


        data[i][1]="".join(listecaracter)
        #split the string on spaces
        data[i][1]=data[i][1].strip().split(' ')
        
 #supprimer les chaines vides       
for i in range(0, len(data)):
    for j in data[i][1] :
        if j=='' :
            data[i][1].remove(j)
 
#TF est une liste qui contient des dictionnaires chacun représente un document(le TF[0] represente le premier document et ainsi de suite)    
TF=[]
for i in range(0, len(data)) :
    a={}
    for j in data[i][1]:
        if j not in a :
            a[j]=1
        else:
            a[j]+=1
    TF.insert(i, a)
print(TF)            
    
#TFD est un dictionnaire qui doit contenire tout les mots de tout les discours avec le nombre de documment dans lesquelles ce mot apparait    
TFD={}
for i in range(0, len(TF)):
    for j in TF[i]:
        if j not in TFD:
            TFD[j]=1
        else:
            TFD[j]+=1   
print(TFD)

# IDF est un dictionnaire qui contient les mots et leur poids
IDF={}
for i in TFD:
    IDF[i]=math.log(len(TF)/TFD[i])
print(IDF)
    
TF_IDF=[]
for i in range(0, len(TF)):
    a={}
    for j in TF[i]:
        a[j]=IDF[j]*TF[i][j]
    TF_IDF.insert(i, a)    
 #noemalizing vectors 
for i in range(0, len(TF_IDF)):
    a=0
    for j in TF_IDF[i]:
        a+=TF_IDF[i][j]*TF_IDF[i][j]
    for j in TF_IDF[i]:
        TF_IDF[i][j]=TF_IDF[i][j]/math.sqrt(a)
print(TF_IDF)

#question 8

#extraction des 20 mots, on choisit le descours numéro 100
ranked_data={}
for j in range(0,20):
    b=[]
    a=0
    for i in TF[100]:
        
        if IDF[i]>a and i not in ranked_data:
            b=[i]
            a=IDF[i]
    ranked_data[b[0]]=IDF[b[0]]
print(ranked_data) 




#question 9
   
annee=1999
decade1={}
decade2={}
for i in range(len(TF)):
        if int(data[i][0])<2009:
            for j in TF_IDF[i]:
                if j not in decade1:
                    decade1[j]=TF_IDF[i][j]
                else:
                    decade1[j]+=TF_IDF[i][j]
        else:
            for j in TF_IDF[i]:
                if j not in decade2:
                    decade2[j]=TF_IDF[i][j]
                else:
                    decade2[j]+=TF_IDF[i][j]
                    
ranked_decade1={}
for j in range(0,20):
    b=[]
    a=0
    for i in decade1:
        
        if decade1[i]>a and i not in ranked_decade1:
            b=[i]
            a=decade1[i]
    ranked_decade1[b[0]]=decade1[b[0]]
    
print(ranked_decade1)    
    
ranked_decade2={}
for j in range(0,20):
    b=[]
    a=0
    for i in decade2:
        
        if decade2[i]>a and i not in ranked_decade2:
            b=[i]
            a=decade2[i]
    ranked_decade2[b[0]]=decade2[b[0]]
print(ranked_decade2)    

            

            
        
        

           
        

      


  
        

    

