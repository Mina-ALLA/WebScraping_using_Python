import requests
import csv
import os
import os.path

from bs4 import BeautifulSoup

soup2 = BeautifulSoup("", 'html.parser')
def writerows(rows, filename):
    with open(filename, 'a', encoding="ascii", errors="ignore") as toWrite:
        writer = csv.writer(toWrite)
        writer.writerow(rows)
        
        
year = []
for i in range(1999,2021) :
    year.append(str(i))

#print(year)    
    
out = "speechKingM6.csv"  
headers = ['date','text']
writerows(headers,out)
if os.path.exists(out):
    os.remove(out)

   
for y in year:
    
    p1=requests.get("http://www.maroc.ma/fr/discours-du-roi?field_type_discours_royal_value_i18n=All&date_discours%5Bvalue%5D%5Byear%5D="+y)
    s1=BeautifulSoup(p1.content, 'html.parser')
    soup2.append(s1.find('div', class_="discours"))
    pagination = s1.find('div', class_="pagination")
    if pagination is None:
            continue
    lesPages=[]
    for page in pagination.find_all('a'):
        lesPages.append(page.get('href')) 
    lesPages.pop(0)
    for i in range (len(lesPages)):
        url='http://www.maroc.ma'+lesPages[i]
        #print(url)
        p2=requests.get(url)
        s2=BeautifulSoup(p2.content, 'html.parser') 
        discours=s2.find('div', class_="discours")
        if discours is None:
            continue
        soup2.append(discours)    
        
        
        for d in discours.find_all() :
            if d is None :
                continue
            type1=d.find('div', class_='type')
            if type1 is None :
                continue
            if type1.text.strip()=='Discours':
                date=d.find('div', class_="date").find('span', class_="date-display-single")
                text_soup=d.find('a', class_="more")
                if None in (date,text_soup):
                    continue
                text_url=text_soup.get('href')    
                p=requests.get('http://www.maroc.ma'+text_url)
                s=BeautifulSoup(p.content, 'html.parser')
                title=s.find('h1', class_="title")
                text1=s.find('div', class_="discours")
                if None in (title,text1):
                    continue 
                d = y
                t = date.text.strip() +" "+ title.text.strip() +" "+ text1.text.strip()
                row = [d,t]   
                writerows(row,out)
                #writerows(+y +","+ date.text.strip() +","+ title.text.strip() +","+ text1.get_text() +"\n",out)
                